package com.alten.remotesync.application.client.record.response;

public record ClientDTO() {
}
