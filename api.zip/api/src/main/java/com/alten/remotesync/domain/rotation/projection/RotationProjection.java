package com.alten.remotesync.domain.rotation.projection;

public interface RotationProjection {
}
