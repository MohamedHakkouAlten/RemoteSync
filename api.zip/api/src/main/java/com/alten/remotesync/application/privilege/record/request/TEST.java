package com.alten.remotesync.application.privilege.record.request;

public class TEST {
}
