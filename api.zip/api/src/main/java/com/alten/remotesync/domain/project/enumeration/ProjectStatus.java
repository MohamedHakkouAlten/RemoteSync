package com.alten.remotesync.domain.project.enumeration;

public enum ProjectStatus {
    ACTIVE,
    INACTIVE,
    PENDING,
    COMPLETED,
    CANCELLED
}
