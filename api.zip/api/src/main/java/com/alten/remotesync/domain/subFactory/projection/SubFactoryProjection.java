package com.alten.remotesync.domain.subFactory.projection;

import java.util.UUID;

public interface SubFactoryProjection {
    UUID getSubFactoryID();
    String getLabel();
}
