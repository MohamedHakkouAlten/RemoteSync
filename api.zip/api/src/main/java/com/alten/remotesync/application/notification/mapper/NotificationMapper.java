package com.alten.remotesync.application.notification.mapper;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface NotificationMapper {
}
