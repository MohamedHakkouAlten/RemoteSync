package com.alten.remotesync.application.log.record.response;

public class TEST {
}
