package com.alten.remotesync.application.client.record.response;

import java.util.UUID;

public record ClientDropDownDTO (

     UUID clientId,

     String label
){
}
