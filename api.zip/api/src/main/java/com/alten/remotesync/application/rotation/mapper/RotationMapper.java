package com.alten.remotesync.application.rotation.mapper;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface RotationMapper {
}
