package com.alten.remotesync.adapter.exception.subFactory;

public class SubFactoryNotFoundException extends  RuntimeException{

  public  SubFactoryNotFoundException(String message){
        super(message);
    }

}
