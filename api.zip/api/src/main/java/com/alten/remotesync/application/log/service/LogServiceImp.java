package com.alten.remotesync.application.log.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class LogServiceImp implements LogService{
}
