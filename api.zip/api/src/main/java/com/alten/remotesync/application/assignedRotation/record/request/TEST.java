package com.alten.remotesync.application.assignedRotation.record.request;

public class TEST {
}
