package com.alten.remotesync.adapter.exception.assignedRotation;

public class AssignedRotationNotFoundException extends RuntimeException {
    public AssignedRotationNotFoundException(String message) { super(message); }
}
