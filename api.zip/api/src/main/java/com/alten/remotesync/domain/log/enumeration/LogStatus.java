package com.alten.remotesync.domain.log.enumeration;

public enum LogStatus {
    SUCCESS,
    FAILURE
}
