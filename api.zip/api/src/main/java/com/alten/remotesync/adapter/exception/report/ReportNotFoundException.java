package com.alten.remotesync.adapter.exception.report;

public class ReportNotFoundException extends RuntimeException {
    public ReportNotFoundException(String message) { super(message); }
}
