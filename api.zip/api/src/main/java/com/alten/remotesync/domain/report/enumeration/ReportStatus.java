package com.alten.remotesync.domain.report.enumeration;

public enum ReportStatus {
    ACCEPTED,
    REJECTED,
    OPENED,
    PENDING
}
