package com.alten.remotesync.application.notification.record.request;

public class TEST {
}
