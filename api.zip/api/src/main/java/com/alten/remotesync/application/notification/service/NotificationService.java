package com.alten.remotesync.application.notification.service;

import org.springframework.stereotype.Service;

@Service
public interface NotificationService {
}
