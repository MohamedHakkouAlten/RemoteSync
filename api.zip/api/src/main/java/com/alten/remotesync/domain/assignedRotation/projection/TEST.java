package com.alten.remotesync.domain.assignedRotation.projection;

public class TEST {

}
