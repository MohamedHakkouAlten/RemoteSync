package com.alten.remotesync.application.project.record.response;

public record ProjectsCountDTO(
        int projectsCount
) {
}
