package com.alten.remotesync.domain.rotation.projection;

public class TEST {

}
