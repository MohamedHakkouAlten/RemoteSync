package com.alten.remotesync.domain.subFactory.projection;

public class TEST {

}
