package com.alten.remotesync.domain.assignedRotation.enumeration;

public enum RotationAssignmentStatus {
    OVERRIDDEN,
    PENDING,
    ACTIVE
}
