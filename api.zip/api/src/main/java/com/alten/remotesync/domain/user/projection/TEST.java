package com.alten.remotesync.domain.user.projection;

public class TEST {
}
