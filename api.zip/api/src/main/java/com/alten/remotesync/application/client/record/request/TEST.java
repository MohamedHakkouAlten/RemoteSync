package com.alten.remotesync.application.client.record.request;

public class TEST {
}
