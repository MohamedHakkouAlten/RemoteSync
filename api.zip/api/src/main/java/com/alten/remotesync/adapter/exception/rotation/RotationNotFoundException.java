package com.alten.remotesync.adapter.exception.rotation;

public class RotationNotFoundException extends RuntimeException {
    public RotationNotFoundException(String message) { super(message); }
}
