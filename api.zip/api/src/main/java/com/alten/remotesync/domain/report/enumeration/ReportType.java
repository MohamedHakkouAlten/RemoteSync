package com.alten.remotesync.domain.report.enumeration;

public enum ReportType {
    REQUEST_ROTATION
}
