package com.alten.remotesync.application.privilege.service;

import org.springframework.stereotype.Service;

@Service
public interface PrivilegeService {
}
