package com.alten.remotesync.application.factory.record.response;

public class TEST {
}
