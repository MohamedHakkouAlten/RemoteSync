package com.alten.remotesync.application.notification.record.response;

public class TEST {
}
