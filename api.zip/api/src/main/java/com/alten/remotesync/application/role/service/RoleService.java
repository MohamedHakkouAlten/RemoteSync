package com.alten.remotesync.application.role.service;

import org.springframework.stereotype.Service;

@Service
public interface RoleService {
}
