package com.alten.remotesync.application.rotation.record;

public class test {
}
