package com.alten.remotesync.domain.notification.enumeration;

public enum NotificationStatus {
    URGENT,
    REQUEST,
    NORMAL,
    IMPORTANT,
    ALERT,
    INFO
}
