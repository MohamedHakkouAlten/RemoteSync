package com.alten.remotesync.domain.report.projection;

public interface ReportUserProjection {
    String getFirstName();
    String getLastName();
}
