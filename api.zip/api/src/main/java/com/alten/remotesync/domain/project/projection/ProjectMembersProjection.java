package com.alten.remotesync.domain.project.projection;

public interface ProjectMembersProjection {
    String getInitials();

}
