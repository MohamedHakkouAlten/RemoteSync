package com.alten.remotesync.application.role.record;

public class test {
}
