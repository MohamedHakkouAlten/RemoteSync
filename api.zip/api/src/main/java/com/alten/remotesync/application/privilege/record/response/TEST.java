package com.alten.remotesync.application.privilege.record.response;

public class TEST {
}
