package com.alten.remotesync.application.log.record.request;

public class TEST {
}
