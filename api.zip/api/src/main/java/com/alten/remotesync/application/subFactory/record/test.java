package com.alten.remotesync.application.subFactory.record;

public class test {
}
