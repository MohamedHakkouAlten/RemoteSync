package com.alten.remotesync.adapter.exception.factory;

public class FactoryNotFoundException extends RuntimeException {
    public FactoryNotFoundException(String message) {
        super(message);
    }
}
