package com.alten.remotesync.application.factory.record.request;

public class TEST {
}
