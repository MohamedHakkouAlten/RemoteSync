package com.alten.remotesync.domain.user.services;

public interface UserDetailsService extends org.springframework.security.core.userdetails.UserDetailsService {
}
